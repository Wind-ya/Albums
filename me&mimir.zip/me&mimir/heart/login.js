// CLOUDS
for(let i=0;i<4;i++){
  const c=document.createElement("div");
  c.className="cloud";
  c.style.top=20+Math.random()*60+"%";
  c.style.animationDuration=60+Math.random()*40+"s";
  document.body.appendChild(c);
}

// STARS
for(let i=0;i<90;i++){
  const s=document.createElement("div");
  s.className="star";
  s.style.top=Math.random()*100+"%";
  s.style.left=Math.random()*100+"%";
  s.style.animationDuration=2+Math.random()*4+"s";
  document.body.appendChild(s);
}

// HANGING STARS
for(let i=0;i<7;i++){
  const h=document.createElement("div");
  h.className="hanging";

// untuk panjang bintangnya 
const total = 7;
const center = (total - 1) / 2;

// jarak dari tengah
const distance = Math.abs(i - center);

// tinggi dasar + tambahan
const base = 60;
const maxExtra = 140;

// makin jauh dari tengah → makin panjang
const length = base + (distance / center) * maxExtra + Math.random() * 20;

h.style.height = length + "px";

  h.style.height=length+"px";
  h.style.left=10+i*12+"%";

  // isi SVG
  h.innerHTML = `
    <div class="star-svg">
      <svg viewBox="0 0 784.11 815.53" xmlns="http://www.w3.org/2000/svg">
        <path d="M392.05 0c-20.9,210.08 -184.06,378.41 -392.05,407.78 
                 207.96,29.37 371.12,197.68 392.05,407.74 
                 20.93,-210.06 184.09,-378.37 392.05,-407.74 
                 -207.98,-29.38 -371.16,-197.69 -392.06,-407.78z"
              fill="#fff6cc"/>
      </svg>
    </div>
  `;

  const angle=2+Math.random()*3;
  const speed=4+Math.random()*5;

  h.animate([
    {transform:`rotate(${-angle}deg)`},
    {transform:`rotate(${angle}deg)`},
    {transform:`rotate(${-angle}deg)`}
  ],{
    duration:speed*1000,
    iterations:Infinity,
    easing:"ease-in-out"
  });

  document.body.appendChild(h);
}

// HEART CLICK
document.addEventListener("DOMContentLoaded", () => {

  const heart = document.querySelector(".heart-btn");
  const input = heart.querySelector("input");

  const PASSWORD = "1010"; // ganti dulu ke "123" buat test

  // klik heart → buka input
  heart.addEventListener("click", (e) => {
    e.stopPropagation();
    heart.classList.add("active");
    input.focus();
  });

  // stop klik di input
  input.addEventListener("click", (e) => {
    e.stopPropagation();
  });

  // ENTER = submit
  input.addEventListener("keydown", (e) => {
    if (e.key === "Enter") {
      e.preventDefault(); // ⬅ PENTING

      console.log("ENTER KEBACA");
      console.log("ISI: ", input.value);

      if (input.value === PASSWORD) {
        console.log("PINDAH KE ALBUM");
        window.location.href = "../album/album.html";
      } else {
       heart.classList.add("shake");
         setTimeout(() => {
           heart.classList.remove("shake");
           heart.classList.remove("active"); // TUTUP BAR
           input.value = "";                // KOSONGIN INPUT
}, 400);

      }
    }
  });

  // klik luar → reset
  document.addEventListener("click", (e) => {
    if (!heart.contains(e.target)) {
      heart.classList.remove("active");
    }
  });

});





