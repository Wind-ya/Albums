

// kartu dan flip

const music = document.getElementById("music");
const toggle = document.getElementById("toggleMusic");




toggle.addEventListener("click",()=>{
  if(music.paused){
    music.play();
    toggle.textContent = "❚❚";
  }else{
    music.pause();
    toggle.textContent = "♫";
  }
});

const sky = document.querySelector(".sky");

/* BINTANG */
for(let i=0;i<80;i++){
  const star = document.createElement("div");
  star.className = "star";
  star.style.top = Math.random()*100 + "%";
  star.style.left = Math.random()*100 + "%";
  star.style.animationDuration = (2 + Math.random()*4) + "s";
  sky.appendChild(star);
}

/* AWAN */
for(let i=0;i<4;i++){
  const cloud = document.createElement("div");
  cloud.className = "cloud";
  cloud.style.top = (10 + Math.random()*60) + "%";
  cloud.style.animationDuration = (60 + Math.random()*40) + "s";
  sky.appendChild(cloud);
}

function createShootingStar(){
  const star = document.createElement("div");
  star.className = "shooting-star";

  // posisi random (atas & samping)
  const startTop = Math.random() * 40; // 0% – 40%
  const startLeft = Math.random() * 60; // 0% – 60%

  star.style.top = startTop + "%";
  star.style.left = startLeft + "%";

  document.body.appendChild(star);

  // animasi manual biar fleksibel
  star.animate([
    { transform: "translate(0,0) rotate(45deg)", opacity: 1 },
    { transform: "translate(600px,600px) rotate(45deg)", opacity: 0 }
  ], {
    duration: 800,
    easing: "ease-out"
  });

  // hapus setelah selesai
  setTimeout(() => {
    star.remove();
  }, 1300);

  // panggil lagi secara RANDOM (tidak bersamaan)
  const nextTime = 2000 + Math.random() * 3000; // 2–5 detik
  setTimeout(createShootingStar, nextTime);
}

// mulai pertama kali (delay dikit)
setTimeout(createShootingStar, 3000);







const track = document.querySelector('.album-track');
const cards = document.querySelectorAll('.album-card');

let currentIndex = 1; // mulai dari tengah

function updateSlider() {

  cards.forEach((card, index) => {
    card.classList.remove('active');

    // 🔥 PAKSA TUTUP semua card dulu
    card.querySelector('.card').classList.remove('flipped');
  });

  cards[currentIndex].classList.add('active');

  const cardWidth = cards[0].offsetWidth;
  const gap = 60;

  const moveX = (cardWidth + gap) * currentIndex;

  track.style.transform =
    `translateX(calc(50% - ${moveX + cardWidth/2}px))`;
}
updateSlider();

cards.forEach((card, index) => {
  card.addEventListener('click', () => {

    if (index !== currentIndex) {
      currentIndex = index;
      updateSlider();
      return;
    }

    card.querySelector('.card').classList.toggle('flipped');
  });
});



